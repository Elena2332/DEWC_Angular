import { Component } from '@angular/core';

@Component({
  selector: 'app-database-tabla',
  templateUrl: './database-tabla.component.html',
  styleUrls: ['./database-tabla.component.css']
})
export class DatabaseTablaComponent {

}
